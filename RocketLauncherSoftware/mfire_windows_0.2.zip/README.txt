mfire (windows) 0.2

This release allows control via a GUI (Tk) based
interface, or via the command line. Please note that
this release should be used on Windows 2000 and XP only.

**Requirements**
   These must be installed before using the program.
 - libusb-win32 (included)
    This must contain driver 0.1.12 or
    newer. It is advised you use the 20060827 Snapshot.
    http://libusb-win32.sourceforge.net/

**Using the GUI (missile-GUI.exe)**
 - Click (and hold if required) on the direction of
    movement you want. Press fire to fire.
 - Right click to change the location of
    missile-control.exe and to view the about screen

**Using the command-command line
    element (missile-control.exe)**
 - missile-control.exe <Commands>
 - <Commands> is any of:
    Direction followed by length in tenths
    of seconds.
 - Directions:
    L       Left
    R       Right
    U       Up
    D       Down
   Or combinations of the above
    (LU, LD, RU, RD) or F to fire.
 - For example: missile-control.exe L 1 RU 2 F LD 1 F

**About**
This program is designed to control M&S USB Missile
 Launchers, and rebranded versions of it.

This program and its source are released under the
 GNU GPL licence, however the following acknowledgements
 must be noted.
 - C Device Control Backend: Ian Jeffray 2005.
 - C Modification for command input and Windows (tm)
    compatibility: Thomas Wood 2006.
 - TCL/TK GUI: Stephen Alderman 2007.

Dependencies and non-vital included items:
 - Libusb: Released under GNU LGPL.
 - Libusb-win32: Released under GNU GPL and GNU LGPL.
 - Blue Graphical Arrows: Released under GNU LGPL by
    David Vignoni. All rights to any modifications made
    are released to him.
 - Fire Button: Released under GNU GPL and GNU LGPL by
   Ian Shortman 2007.

A copy of the GNU GPL licence can be found at
 http://www.gnu.org/licenses/gpl.html and the GNU LGPL
 licence can be found at
 http://www.gnu.org/licenses/lgpl.html.

Credits:
 - The C backend is compiled for Windows (tm) using MinGW.
