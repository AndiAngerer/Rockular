# MissileSharp

MissileSharp is a .NET library to control an USB Missile Launcher.

See [http://christianspecht.de/missilesharp](http://christianspecht.de/missilesharp) for more information.


### License

MissileSharp is licensed under the MIT License. See [License.txt](https://bitbucket.org/christianspecht/missilesharp/raw/tip/License.txt) for details.